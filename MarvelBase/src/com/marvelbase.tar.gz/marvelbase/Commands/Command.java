package com.marvelbase.Commands;

public interface Command {
	boolean execute();
}
